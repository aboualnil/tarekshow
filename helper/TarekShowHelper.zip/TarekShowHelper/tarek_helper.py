# -*- coding: utf-8 -*-
"""
Tarek Show Helper
A small local server for the "Tweets" tab of the Tarek Show studio.
It reads a YouTube episode (info, Arabic captions, audio) and cuts clips by timecode.
Runs only on this computer (127.0.0.1) and answers only the studio's own site.
"""
import json
import os
import re
import shutil
import sys
import sysconfig
import tempfile
import threading
import time
import traceback
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

try:
    sys.stdout.reconfigure(errors="replace")
except Exception:
    pass

VERSION = "1.0"
PORT = int(os.environ.get("TSS_HELPER_PORT", "8787"))
ALLOWED_ORIGINS = (
    "https://ai-digital-team.github.io",
    "http://localhost",
    "http://127.0.0.1",
)

# Make pip-installed tools (deno, yt-dlp) visible to yt-dlp even if Scripts is not on PATH.
for scheme in (None, os.name + "_user"):
    try:
        p = sysconfig.get_path("scripts", scheme) if scheme else sysconfig.get_path("scripts")
        if p and os.path.isdir(p) and p not in os.environ.get("PATH", ""):
            os.environ["PATH"] = p + os.pathsep + os.environ.get("PATH", "")
    except Exception:
        pass

try:
    import yt_dlp
    from yt_dlp.utils import download_range_func
except ImportError:
    print("\n[!] yt-dlp is not installed. Run Install.bat first.\n")
    input("Press Enter to close...")
    sys.exit(1)

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, "tools")
OUTDIR = os.path.join(os.path.expanduser("~"), "Videos", "Tarek Show Clips")
WORK = tempfile.mkdtemp(prefix="tss_helper_")
os.makedirs(OUTDIR, exist_ok=True)


def find_ffmpeg_dir():
    """Return a folder that holds ffmpeg(.exe), using the copy bundled with imageio-ffmpeg if needed."""
    if shutil.which("ffmpeg"):
        return os.path.dirname(shutil.which("ffmpeg"))
    exe = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
    local = os.path.join(TOOLS, exe)
    if os.path.isfile(local):
        return TOOLS
    try:
        import imageio_ffmpeg
        src = imageio_ffmpeg.get_ffmpeg_exe()
        os.makedirs(TOOLS, exist_ok=True)
        shutil.copy2(src, local)
        return TOOLS
    except Exception:
        return None


FFDIR = find_ffmpeg_dir()
LOCK = threading.Lock()
INFO_CACHE = {}


def base_opts():
    o = {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "noplaylist": True,
        "retries": 3,
        "socket_timeout": 30,
    }
    if FFDIR:
        o["ffmpeg_location"] = FFDIR
    cookies = os.path.join(HERE, "cookies.txt")
    if os.path.isfile(cookies):
        o["cookiefile"] = cookies
    return o


def clean_url(u):
    u = (u or "").strip()
    m = re.search(r"(?:v=|youtu\.be/|shorts/|live/|embed/)([A-Za-z0-9_-]{11})", u)
    if m:
        return "https://www.youtube.com/watch?v=" + m.group(1), m.group(1)
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", u):
        return "https://www.youtube.com/watch?v=" + u, u
    raise ValueError("bad_url")


def get_info(url):
    url, vid = clean_url(url)
    hit = INFO_CACHE.get(vid)
    if hit and time.time() - hit[0] < 1800:
        return hit[1]
    with yt_dlp.YoutubeDL(base_opts()) as ydl:
        info = ydl.extract_info(url, download=False)
    INFO_CACHE[vid] = (time.time(), info)
    return info


def pick_captions(info):
    """Prefer manual Arabic subtitles, then the original-language Arabic auto captions."""
    def find(tracks, keys):
        for k in keys:
            if k in tracks:
                return k, tracks[k]
        for k, v in tracks.items():
            if k.split("-")[0] == "ar":
                return k, v
        return None, None

    for kind, tracks in (("manual", info.get("subtitles") or {}), ("auto", info.get("automatic_captions") or {})):
        key, fmts = find(tracks, ("ar", "ar-orig", "ar-SA") if kind == "manual" else ("ar-orig", "ar"))
        if fmts:
            j = next((f for f in fmts if f.get("ext") == "json3"), None)
            if j:
                return kind, key, j["url"]
    return None, None, None


def json3_to_lines(data):
    events = data.get("events") or []
    raw = []
    for ev in events:
        segs = ev.get("segs")
        if not segs or "tStartMs" not in ev:
            continue
        text = "".join(s.get("utf8", "") for s in segs).replace("\n", " ").strip()
        text = re.sub(r"\s+", " ", text)
        if text:
            raw.append({"t": ev["tStartMs"] / 1000.0, "s": text})
    # Merge tiny fragments into readable lines (like YouTube's transcript panel)
    lines = []
    for r in raw:
        if lines and (len(lines[-1]["s"].split()) < 6 or r["t"] - lines[-1]["t"] < 1.5) and r["t"] - lines[-1]["t"] < 8 and len(lines[-1]["s"].split()) < 16:
            lines[-1]["s"] += " " + r["s"]
        else:
            lines.append(dict(r))
    return lines


def safe_name(s, n=60):
    s = re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", s or "").strip()
    return re.sub(r"\s+", " ", s)[:n].strip() or "clip"


def tcf(sec):
    sec = int(round(sec))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return (f"{h}-{m:02d}-{s:02d}" if h else f"{m:02d}-{s:02d}")


class H(BaseHTTPRequestHandler):
    server_version = "TarekHelper/" + VERSION

    def log_message(self, fmt, *args):
        sys.stdout.write("  " + time.strftime("%H:%M:%S") + "  " + (fmt % args) + "\n")

    # ---- CORS / origin guard ----
    def origin_ok(self):
        o = self.headers.get("Origin")
        if not o:
            return True  # direct visit from this computer (e.g. opening /ping in a browser)
        return any(o == a or o.startswith(a + ":") for a in ALLOWED_ORIGINS)

    def cors(self):
        o = self.headers.get("Origin")
        if o and self.origin_ok():
            self.send_header("Access-Control-Allow-Origin", o)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Expose-Headers", "Content-Disposition, X-Saved-Path, X-File-Name")

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, name, mime):
        size = os.path.getsize(path)
        self.send_response(200)
        self.cors()
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(size))
        self.send_header("X-File-Name", name.encode("utf-8").hex())
        self.send_header("X-Saved-Path", path.encode("utf-8").hex())
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile, 1024 * 1024)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_OPTIONS(self):
        if not self.origin_ok():
            self.send_response(403)
            self.end_headers()
            return
        self.send_response(204)
        self.cors()
        self.end_headers()

    def do_GET(self):
        if not self.origin_ok():
            return self.send_json(403, {"error": "origin"})
        u = urlparse(self.path)
        if u.path == "/ping":
            return self.send_json(200, {"ok": True, "version": VERSION, "ytdlp": yt_dlp.version.__version__,
                                        "ffmpeg": bool(FFDIR), "folder": OUTDIR})
        if u.path == "/audio":
            q = parse_qs(u.query)
            return self.guard(lambda: self.audio(q.get("url", [""])[0]))
        return self.send_json(404, {"error": "not_found"})

    def do_POST(self):
        if not self.origin_ok():
            return self.send_json(403, {"error": "origin"})
        u = urlparse(self.path)
        try:
            data = self.body_json()
        except Exception:
            return self.send_json(400, {"error": "bad_json"})
        routes = {"/info": self.info, "/transcript": self.transcript, "/clip": self.clip}
        fn = routes.get(u.path)
        if not fn:
            return self.send_json(404, {"error": "not_found"})
        return self.guard(lambda: fn(data))

    def guard(self, fn):
        try:
            fn()
        except ValueError as e:
            self.send_json(400, {"error": str(e)})
        except yt_dlp.utils.DownloadError as e:
            msg = str(e)
            code = "private" if re.search(r"private|members|sign in|age", msg, re.I) else "youtube"
            print("  [youtube] " + msg[:300])
            self.send_json(502, {"error": code, "detail": msg[:400]})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            traceback.print_exc()
            try:
                self.send_json(500, {"error": "helper", "detail": str(e)[:400]})
            except Exception:
                pass

    # ---- routes ----
    def info(self, d):
        info = get_info(d.get("url"))
        kind, key, _ = pick_captions(info)
        self.send_json(200, {
            "id": info.get("id"), "title": info.get("title"), "channel": info.get("channel") or info.get("uploader"),
            "duration": info.get("duration"), "thumbnail": info.get("thumbnail"),
            "upload_date": info.get("upload_date"), "captions": kind, "captions_lang": key,
        })

    def transcript(self, d):
        info = get_info(d.get("url"))
        kind, key, url = pick_captions(info)
        if not url:
            raise ValueError("no_captions")
        with yt_dlp.YoutubeDL(base_opts()) as ydl:
            raw = ydl.urlopen(url).read()
        lines = json3_to_lines(json.loads(raw.decode("utf-8")))
        if not lines:
            raise ValueError("no_captions")
        self.send_json(200, {"kind": kind, "lang": key, "lines": lines})

    def audio(self, url):
        url, vid = clean_url(url)
        out = os.path.join(WORK, vid + "_audio")
        existing = [f for f in os.listdir(WORK) if f.startswith(vid + "_audio.")]
        if not existing:
            opts = base_opts()
            opts.update({"format": "bestaudio[ext=m4a]/bestaudio", "outtmpl": out + ".%(ext)s"})
            with LOCK:
                with yt_dlp.YoutubeDL(opts) as ydl:
                    ydl.download([url])
            existing = [f for f in os.listdir(WORK) if f.startswith(vid + "_audio.")]
        if not existing:
            raise ValueError("audio_failed")
        path = os.path.join(WORK, existing[0])
        ext = path.rsplit(".", 1)[-1]
        self.send_file(path, vid + "." + ext, "audio/mp4" if ext == "m4a" else "audio/" + ext)

    def clip(self, d):
        url, vid = clean_url(d.get("url"))
        start, end = float(d.get("start", 0)), float(d.get("end", 0))
        if end <= start or end - start > 3 * 3600:
            raise ValueError("bad_range")
        if not FFDIR:
            raise ValueError("no_ffmpeg")
        q = int(d.get("height") or 1080)
        name = safe_name(f"TarekShow_{tcf(start)}_{tcf(end)}_{d.get('title') or vid}", 90)
        path = os.path.join(OUTDIR, name + ".mp4")
        tmp = os.path.join(WORK, f"{vid}_{int(start*1000)}_{int(end*1000)}_{q}")
        opts = base_opts()
        opts.update({
            "format": f"bv*[height<={q}][ext=mp4]+ba[ext=m4a]/b[height<={q}][ext=mp4]/bv*[height<={q}]+ba/b",
            "merge_output_format": "mp4",
            "download_ranges": download_range_func(None, [(start, end)]),
            "force_keyframes_at_cuts": True,
            "outtmpl": tmp + ".%(ext)s",
            "overwrites": True,
        })
        print(f"  [clip] {tcf(start)} -> {tcf(end)}  {d.get('title') or ''}")
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
        made = [f for f in os.listdir(WORK) if f.startswith(os.path.basename(tmp) + ".") and not f.endswith(".part")]
        if not made:
            raise ValueError("clip_failed")
        src = os.path.join(WORK, sorted(made, key=lambda f: not f.endswith(".mp4"))[0])
        shutil.move(src, path)
        self.send_file(path, name + ".mp4", "video/mp4")


def main():
    print("=" * 56)
    print("  Tarek Show Helper  v" + VERSION)
    print("  yt-dlp " + yt_dlp.version.__version__ + ("   ffmpeg OK" if FFDIR else "   [!] ffmpeg missing"))
    print("  Clips are saved in: " + OUTDIR)
    print("  Keep this window open while you use the Tweets tab.")
    print("=" * 56)
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    except OSError:
        print(f"\n[!] Port {PORT} is busy. The helper may already be running in another window.\n")
        input("Press Enter to close...")
        return
    srv.daemon_threads = True
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        shutil.rmtree(WORK, ignore_errors=True)


if __name__ == "__main__":
    main()
