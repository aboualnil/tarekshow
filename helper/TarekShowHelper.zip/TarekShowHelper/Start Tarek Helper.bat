@echo off
title Tarek Show Helper
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  echo  Python is missing. Run Install.bat first.
  pause
  exit /b 1
)
echo  Checking for yt-dlp updates...
%PY% -m pip install --upgrade --quiet "yt-dlp[default]" 2>nul
%PY% "%~dp0tarek_helper.py"
pause
