@echo off
setlocal
title Tarek Show Helper - Install
cd /d "%~dp0"
echo.
echo  ===== Tarek Show Helper : Install =====
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )

if not defined PY (
  echo  Python is not installed. Installing Python 3.12 with winget...
  winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
  echo.
  echo  ------------------------------------------------------------
  echo   Python was installed. CLOSE this window and run Install.bat
  echo   one more time to finish.
  echo  ------------------------------------------------------------
  pause
  exit /b
)

echo  Using: %PY%
%PY% -m pip install --upgrade pip
%PY% -m pip install --upgrade "yt-dlp[default]" imageio-ffmpeg
if errorlevel 1 (
  echo.
  echo  [!] Installing yt-dlp failed. Check the internet connection and try again.
  pause
  exit /b 1
)

echo.
echo  Installing Deno (YouTube needs it for downloads)...
%PY% -m pip install --upgrade deno
if errorlevel 1 (
  winget install -e --id DenoLand.Deno --accept-source-agreements --accept-package-agreements
)

echo.
echo  Preparing ffmpeg...
%PY% -c "import imageio_ffmpeg,shutil,os;os.makedirs('tools',exist_ok=True);shutil.copy2(imageio_ffmpeg.get_ffmpeg_exe(),os.path.join('tools','ffmpeg.exe'));print('  ffmpeg OK')"

echo.
echo  Creating a desktop shortcut...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Tarek Show Helper.lnk');$s.TargetPath='%~dp0Start Tarek Helper.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%SystemRoot%\System32\shell32.dll,137';$s.Save()"

echo.
echo  ===== Done =====
echo  From now on, open "Tarek Show Helper" from the Desktop before using the Tweets tab.
echo.
pause
